package org.app.service.rest;

//@javax.ws.rs.ApplicationPath("resources")
@javax.ws.rs.ApplicationPath("/rest")
public class ApplicationConfig extends javax.ws.rs.core.Application {

}