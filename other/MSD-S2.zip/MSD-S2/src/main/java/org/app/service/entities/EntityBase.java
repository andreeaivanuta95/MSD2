package org.app.service.entities;

public class EntityBase {

	
}
